package ChristmasRaces.src.main.java.christmasRaces.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
