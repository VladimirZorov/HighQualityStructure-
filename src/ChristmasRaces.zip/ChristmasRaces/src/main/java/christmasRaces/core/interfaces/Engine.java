package ChristmasRaces.src.main.java.christmasRaces.core.interfaces;

public interface Engine extends Runnable {
}
